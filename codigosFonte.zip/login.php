





<style>


body {
    background-color: black;
    color: #00ff00;
    font-family: 'Courier New', Courier, monospace;
    text-align: center;
    margin-top: 100px;
}

.matrix-container {
    display: inline-block;
    background-color: rgba(0, 255, 0, 0.1);
    padding: 40px;
    border: 2px solid #00ff00;
    border-radius: 10px;
}

</style>
